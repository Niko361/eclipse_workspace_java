public enum moveDirection
{
	Up,
	Right,
	Down,
	Left
}
