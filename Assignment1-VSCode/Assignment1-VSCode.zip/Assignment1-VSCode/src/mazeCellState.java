public enum mazeCellState
{
	Empty,
	Wall,
	Agent
}
