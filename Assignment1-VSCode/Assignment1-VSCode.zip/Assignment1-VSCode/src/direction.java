public enum direction
{
	Up,
	Left,
	Down,
	Right
};
